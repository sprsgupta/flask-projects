from market import app,db, models, routes
if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    # migrate.init()
    app.run(port=8080,debug=True)
